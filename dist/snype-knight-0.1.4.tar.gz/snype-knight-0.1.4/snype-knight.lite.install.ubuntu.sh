#!/bin/bash
####    snype-knight.lite.install.sh    ####
#
# @author Gary Wilson (gary.wilson@of-networks.co.uk)
# @created 20110116 - Feature #81: snype-knight1
# @based on work from Feature #84: snype-knight1.snyping.com
# @modified 20111203 - Bug #245: mail version
# @modified 20111203 - Feature #247: version.number
# @modified 20111218 - Feature #276: Do not recheck requirements
# @modified 20120102 - Feature #247: version.number - used SCRIPTPATH
# @copyright of-networks.co.uk 2011
# @source https://svn.of-networks.co.uk/svn/snype-knight/trunk/snype-knight.lite.install.sh
# @local /var/scripts/snype-knight/snype-knight.lite.install.sh

########
# GLOBAL VARIABLES WITH DEPENDENCIES IN OTHER SCRIPTS

VERSION=0.1.3
MASTER_PACKAGE=snype-knight.lite

# END - GLOBAL VARIABLES
########

# Absolute path to this script
SCRIPT=$(readlink -f $0)
SCRIPTNAME=$(basename "$SCRIPT")
SCRIPTPATH=$(dirname $SCRIPT)
SERVER=`hostname | cut -d'.' -f1-1`
TIMESTAMP=`date +%s`
RUNDATE=`date -d @$TIMESTAMP +%Y%m%d%H%M%S`
SNYPE_LOG_PATH=/var/log/$MASTER_PACKAGE
LOGFILE=$SNYPE_LOG_PATH/$RUNDATE.$SCRIPTNAME.log

# snype-knight.lite app change
CHANGE_CONTROL_ALERT1=0

if [ ! -d $SNYPE_LOG_PATH/backups ]; then
  mkdir -p $SNYPE_LOG_PATH/backups
fi

echo -e "\n\n################################################################################
#
# $MASTER_PACKAGE Install - Version $VERSION
#
################################################################################

`date`

Logging to $LOGFILE" | tee -a $LOGFILE

echo -e "\n##################
#  
#  STARTING - REQUIREMENTS CHECKS
#
##################\n" | tee -a $LOGFILE
sleep 2

echo -e "\n######\n# Checking $MASTER_PACKAGE.conf\n" | tee -a $LOGFILE

CONFIG_EXISTS=0

if [ ! -h /etc/$MASTER_PACKAGE/$MASTER_PACKAGE.conf ]; then
  if [ ! -f /usr/local/$MASTER_PACKAGE/etc/$MASTER_PACKAGE.conf ]; then
  #    echo "Trying to get server $SERVER $MASTER_PACKAGE.conf from SVN" | tee -a $LOGFILE
  #    echo "Trying https://svn.of-networks.co.uk/svn/infrastructure/$SERVER/usr/local/$MASTER_PACKAGE/etc/$MASTER_PACKAGE.conf" | tee -a $LOGFILE
  #    cd $SCRIPTPATH/etc
  #    svn export --force https://svn.of-networks.co.uk/svn/infrastructure/$SERVER/usr/local/$MASTER_PACKAGE/etc/$MASTER_PACKAGE.conf
  #    if [ -f $SCRIPTPATH/etc/$MASTER_PACKAGE.conf ]; then
  #      echo "Retrieved $SERVER $MASTER_PACKAGE.conf from SVN" | tee -a $LOGFILE
  #    else
  #      echo "Did NOT retrieve $SERVER $MASTER_PACKAGE.conf from SVN" | tee -a $LOGFILE    
  #    fi
    echo "No $MASTER_PACKAGE.conf at /usr/local/$MASTER_PACKAGE/etc/$MASTER_PACKAGE.conf" | tee -a $LOGFILE    
  else
    echo -e "\nFound config /usr/local/$MASTER_PACKAGE/etc/$MASTER_PACKAGE.conf - OK\n" | tee -a $LOGFILE
    mkdir -p /etc/$MASTER_PACKAGE
    echo "symlinking /usr/local/$MASTER_PACKAGE/etc/$MASTER_PACKAGE.conf to /etc/$MASTER_PACKAGE/$MASTER_PACKAGE.conf" | tee -a $LOGFILE
    ln -s /usr/local/$MASTER_PACKAGE/etc/$MASTER_PACKAGE.conf /etc/$MASTER_PACKAGE/$MASTER_PACKAGE.conf
    CONFIG_EXISTS=0
  fi

  if [ $CONFIG_EXISTS -eq 0 ]; then
    if [ ! -f $SCRIPTPATH/etc/$MASTER_PACKAGE.conf ]; then
      echo "$SCRIPTPATH/etc/$MASTER_PACKAGE.conf NOT FOUND, exiting" | tee -a $LOGFILE
      exit 1
    else
      echo -e "\n$SCRIPTPATH/etc/$MASTER_PACKAGE.conf found - OK\n" | tee -a $LOGFILE
      DETERMINED_CONFIG_FILE=$SCRIPTPATH/etc/$MASTER_PACKAGE.conf
    fi
  fi
else
  DETERMINED_CONFIG_FILE=/etc/$MASTER_PACKAGE/$MASTER_PACKAGE.conf
fi

DEFAULT_CONF_PARAMETER_COUNT=`cat $DETERMINED_CONFIG_FILE | grep -v "^#" | grep -c '="your_'`
if [ "$DEFAULT_CONF_PARAMETER_COUNT" -gt "0" ]; then
  echo -e "\nPlease ensure that you have modified the $MASTER_PACKAGE.conf file:
$DETERMINED_CONFIG_FILE\n
A check found the default configuration string/s of 'your_'.  Please ensure you
have replaced all the 'your_' values with the relevant parameters.\n\n" | tee -a $LOGFILE
  exit 1
else
  echo -e "\nNo default configuration strings found - OK\n" | tee -a $LOGFILE
fi
sleep 2

# Get ADMIN_EMAIL
source $DETERMINED_CONFIG_FILE

####
# Checking requirements

#REQUIREMENTS="iputils mailx coreutils net-tools sed grep iptables"
REQUIREMENTS="mailutils coreutils net-tools sed grep iptables"
apt-get -y install $REQUIREMENTS | tee -a $LOGFILE

echo -e "\n######\n# Checking ping\n" | tee -a $LOGFILE
ping -V
if [ $? -ne 0 ]; then
  echo "ping NOT FOUND, exiting. Try 'apt-get install iputils'" | tee -a $LOGFILE
  exit 1
else
  echo -e "\nping found - OK\n" | tee -a $LOGFILE
  sleep 2
fi

echo -e "\n######\n# Checking mail capable\n" | tee -a $LOGFILE
mail --version > /dev/null 2>&1
if [ $? -ne 0 ]; then
  #######
  # START - Bug #245: mail version
  #echo "mail NOT FOUND, exiting. Try 'yum install mailx'" | tee -a $LOGFILE
  #exit 1
  mail -V > /dev/null 2>&1
  if [ $? -ne 0 ]; then
    echo "mail NOT FOUND, exiting. Try 'yum install mailx'" | tee -a $LOGFILE
    exit 1
  else
    echo -e "\nmail found - OK\n" | tee -a $LOGFILE
    sleep 2
  fi
  # END - Bug #245: mail version
  #######
else
  echo -e "\nmail found - OK\n" | tee -a $LOGFILE
  sleep 2
fi

PACKAGE_LIST="cat sed grep ifconfig iptables"
for i in $PACKAGE_LIST
do
echo -e "\n######\n# Checking $i\n" | tee -a $LOGFILE
if [ "$i" = "ifconfig" ]; then
  stat /sbin/$i
else
  $i --version
fi
if [ $? -ne 0 ]; then
  [ "$i" = "cat" ] && echo -e "\n\n$i NOT FOUND, exiting. Try 'apt-get install coreutils' and please see the README document\n\n" | tee -a $LOGFILE
  [ "$i" = "ifconfig" ] && echo -e "\n\n$i NOT FOUND, exiting. Try 'apt-get install net-tools' and please see the README document\n\n" | tee -a $LOGFILE
  echo -e "\n\n$i NOT FOUND, exiting. Try 'apt-get install "$i"' and please see the README document\n\n" | tee -a $LOGFILE
  exit 1
else
  echo -e "\n$i found - OK\n" | tee -a $LOGFILE
  sleep 2
fi
done

#####
# START - Feature #276: Do not recheck requirements
echo "$TIMESTAMP" > /usr/local/$MASTER_PACKAGE/do.not.delete.requirements.check.done.log

########
# Installing
echo "Installing $MASTER_PACKAGE to /usr/local/$MASTER_PACKAGE" | tee -a $LOGFILE

mkdir -p /usr/local/$MASTER_PACKAGE/bin
mkdir -p /usr/local/$MASTER_PACKAGE/etc

echo "Installing /usr/local/$MASTER_PACKAGE/bin/$MASTER_PACKAGE" | tee -a $LOGFILE
echo "Checking for old /usr/local/$MASTER_PACKAGE/bin/$MASTER_PACKAGE" | tee -a $LOGFILE
if [ -f /usr/local/$MASTER_PACKAGE/bin/$MASTER_PACKAGE ]; then
  CHANGE_CONTROL_ALERT1=1
  OLD_VERSION=`cat /usr/local/$MASTER_PACKAGE/bin/$MASTER_PACKAGE | grep "^VERSION="`
  echo "Old version found - Version $OLD_VERSION" | tee -a $LOGFILE
  echo "Old version found - Version $OLD_VERSION" | tee -a $LOGFILE
  mv /usr/local/$MASTER_PACKAGE/bin/$MASTER_PACKAGE /usr/local/$MASTER_PACKAGE/bin/$MASTER_PACKAGE.pre.$VERSION.$RUNDATE
  echo "Moved to /usr/local/$MASTER_PACKAGE/bin/$MASTER_PACKAGE.pre.$VERSION.$RUNDATE" | tee -a $LOGFILE
  echo "PLEASE NOTE:" | tee $LOGFILE.alert1
  echo "/usr/local/$MASTER_PACKAGE/bin/$MASTER_PACKAGE was changed." | tee -a $LOGFILE.alert1
  echo "SHOULD you run change control on this file please ensure that you version control is updated" | tee -a $LOGFILE.alert1
else
  echo "No old version found" | tee -a $LOGFILE
fi

/bin/cp -fp $SCRIPTPATH/bin/$MASTER_PACKAGE /usr/local/$MASTER_PACKAGE/bin/$MASTER_PACKAGE
chmod 0755 /usr/local/$MASTER_PACKAGE/bin/$MASTER_PACKAGE

#######
# START - Feature #247: version.number
PRESENT_DIR=`pwd`
#SNYPE_KNIGHT_VERSION_NUMBER=`basename `pwd` | cut -d'-' -f3-6`
#SNYPE_KNIGHT_VERSION_NUMBER=`basename $PRESENT_DIR | cut -d'-' -f3-6`
SNYPE_KNIGHT_VERSION_NUMBER=`basename $SCRIPTPATH | cut -d'-' -f3-6`
cat /usr/local/$MASTER_PACKAGE/bin/$MASTER_PACKAGE | sed -e 's/VERSION=SNYPE_KNIGHT_VERSION_NUMBER/VERSION='$SNYPE_KNIGHT_VERSION_NUMBER'/g'> /tmp/$MASTER_PACKAGE
cat /tmp/$MASTER_PACKAGE > /usr/local/$MASTER_PACKAGE/bin/$MASTER_PACKAGE
echo "$SNYPE_KNIGHT_VERSION_NUMBER" > /usr/local/$MASTER_PACKAGE/version
rm -rf /usr/local/$MASTER_PACKAGE/version.*
echo "$SNYPE_KNIGHT_VERSION_NUMBER" > /usr/local/$MASTER_PACKAGE/version.$SNYPE_KNIGHT_VERSION_NUMBER
# END - Feature #247: version.number
#######

echo "Installed /usr/local/$MASTER_PACKAGE/bin/$MASTER_PACKAGE" | tee -a $LOGFILE

# Manage symlink
[[ -h /usr/local/bin/$MASTER_PACKAGE ]] && rm -f /usr/local/bin/$MASTER_PACKAGE
echo "symlinking /usr/local/bin/$MASTER_PACKAGE to /usr/local/$MASTER_PACKAGE/bin/$MASTER_PACKAGE" | tee -a $LOGFILE
ln -s /usr/local/$MASTER_PACKAGE/bin/$MASTER_PACKAGE /usr/local/bin/$MASTER_PACKAGE

echo "Installing $SCRIPTPATH/etc/$MASTER_PACKAGE.conf to /usr/local/$MASTER_PACKAGE/etc/$MASTER_PACKAGE.conf" | tee -a $LOGFILE
if [ -f /usr/local/$MASTER_PACKAGE/etc/$MASTER_PACKAGE.conf ]; then
  echo "Existing configure found, NOT OVERWRITING" | tee -a $LOGFILE
else
  echo "Installing $SCRIPTPATH/etc/$MASTER_PACKAGE.conf to /usr/local/$MASTER_PACKAGE/etc/$MASTER_PACKAGE.conf" | tee -a $LOGFILE
  /bin/cp -f $SCRIPTPATH/etc/$MASTER_PACKAGE.conf /usr/local/$MASTER_PACKAGE/etc/$MASTER_PACKAGE.conf
  mkdir -p /etc/$MASTER_PACKAGE
  [[ -h /etc/$MASTER_PACKAGE/$MASTER_PACKAGE.conf ]] && rm -f /etc/$MASTER_PACKAGE/$MASTER_PACKAGE.conf
  echo "symlinking /usr/local/$MASTER_PACKAGE/etc/$MASTER_PACKAGE.conf to /etc/$MASTER_PACKAGE/$MASTER_PACKAGE.conf" | tee -a $LOGFILE
  ln -s /usr/local/$MASTER_PACKAGE/etc/$MASTER_PACKAGE.conf /etc/$MASTER_PACKAGE/$MASTER_PACKAGE.conf
fi

########
# Email report

if [ $CHANGE_CONTROL_ALERT1 = 1 ]; then
  cat $LOGFILE.alert1 | tee $LOGFILE.email
fi

cat $LOGFILE >> $LOGFILE.email

SUBJECT="$SERVER - $MASTER_PACKAGE"
echo "Mailing $ADMIN_EMAIL - $SUBJECT - report and log" | tee -a $LOGFILE
echo "
###########
#
#
#   $MASTER_PACKAGE installed and can be run with:
#   
#   $MASTER_PACKAGE
#   or
#   /usr/local/$MASTER_PACKAGE/bin/$MASTER_PACKAGE
#   or
#   /usr/local/bin/$MASTER_PACKAGE
#
#
###########
" | tee -a $LOGFILE

mail -s "$SUBJECT" $ADMIN_EMAIL <<EOF

`date`
Log from $MASTER_PACKAGE by $SCRIPT

`cat $LOGFILE.email`

EOF

